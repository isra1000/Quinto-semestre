/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamenMedio;

/**
 *
 * @author Israel
 */
public class AccionArealizar2 implements Runnable{
     Octal c2;
        @Override
        public void run() {
            System.out.println("De decimal a octal");
            System.out.println(c2.x);
        }
            public void sett2(Octal o1){
                this.c2 = c2;
            }
        }
     
      

